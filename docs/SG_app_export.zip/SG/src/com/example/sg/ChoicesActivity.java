package com.example.sg;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.Menu;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;

public class ChoicesActivity extends Activity {
	public int REQUEST_SD_ACTIVITY = 1;
	

	public void launchSendData(View v){
		startActivityForResult(   new Intent(getApplicationContext(), com.example.sg.SendDataActivity.class),
                REQUEST_SD_ACTIVITY);
	}
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		 requestWindowFeature(Window.FEATURE_NO_TITLE);
	        setContentView(R.layout.activity_choices);
	        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.activity_choices, menu);
		return true;
	}
	
	public void startAccel(View v){
		 try {
			SG.manager.semBTout.acquire();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		 SG.connectedThread.write(new byte[]{CMD.SOT,CMD.SWCHMOD,MOD.ACCEL,CMD.EOT});
		 SG.manager.semBTout.release();
		 STATE.CURRENT_MODE=MOD.ACCEL;
	}
	public void starManual(View v){
		 Intent intent = new Intent(this, SendDataActivity.class);
		 startActivity(intent);
	}
	public void startClock(View v){
		SG.manager.updateRTC();
		 try {
			SG.manager.semBTout.acquire();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		 SG.connectedThread.write(new byte[]{CMD.SOT,CMD.SWCHMOD,MOD.CLOCK,CMD.EOT});
		 SG.manager.semBTout.release();
		 STATE.CURRENT_MODE=MOD.CLOCK;
	}
	public void startLog(View v){
		 try {
			SG.manager.semBTout.acquire();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		 SG.connectedThread.write(new byte[]{CMD.SOT,CMD.SWCHMOD,MOD.LOG,CMD.EOT});
		 if(STATE.CALL_NOTIFIED){
			 STATE.CALL_NOTIFIED=false;
	   			SG.connectedThread.write(new byte[]{CMD.SOT,CMD.OFFCALL,CMD.EOT});
		 }
		 if(STATE.SMS_NOTIFIED){
			 STATE.SMS_NOTIFIED=false;
	   			SG.connectedThread.write(new byte[]{CMD.SOT,CMD.OFFSMS,CMD.EOT});
		 }
		 SG.manager.semBTout.release();
		 STATE.CURRENT_MODE=MOD.LOG;
	}
	public void startDemo(View v){
		 try {
			SG.manager.semBTout.acquire();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		 SG.connectedThread.write(new byte[]{CMD.SOT,CMD.SWCHMOD,MOD.DEMO,CMD.EOT});
		 SG.manager.semBTout.release();
		 STATE.CURRENT_MODE=MOD.DEMO;
	}
	public void startDebug(View v){
		 try {
			SG.manager.semBTout.acquire();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		 SG.connectedThread.write(new byte[]{CMD.SOT,CMD.DEBUG,CMD.EOT});
		 SG.manager.semBTout.release();
		 
	}
	public void switchGPS(View v){
		 try {
			SG.manager.semBTout.acquire();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		 SG.connectedThread.write(new byte[]{CMD.SOT,CMD.GPS,CMD.EOT});
		 SG.manager.semBTout.release();
		 
	}
	public void switchAlarm(View v){
		 try {
			SG.manager.semBTout.acquire();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		 SG.connectedThread.write(new byte[]{CMD.SOT,CMD.ALARM,CMD.EOT});
		 SG.manager.semBTout.release();
	}

}
