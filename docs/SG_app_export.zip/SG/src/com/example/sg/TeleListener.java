package com.example.sg;

import android.telephony.PhoneStateListener;
import android.telephony.TelephonyManager;
import android.util.Log;

public class TeleListener extends PhoneStateListener{
	public void onCallStateChanged(int state, String incomingNumber) {
	
		   super.onCallStateChanged(state, incomingNumber);
		   switch (state) {
		   case TelephonyManager.CALL_STATE_IDLE:
		    // CALL_STATE_IDLE;
		   
		    break;
		   case TelephonyManager.CALL_STATE_OFFHOOK:
		    // CALL_STATE_OFFHOOK;
			   try {
					SG.manager.semBTout.acquire();
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			   		if(STATE.CALL_NOTIFIED){
			   			STATE.CALL_NOTIFIED=false;
			   			SG.connectedThread.write(new byte[]{CMD.SOT,CMD.OFFCALL,CMD.EOT});
			   			SG.connectedThread.write(new byte[]{CMD.SOT,CMD.OFFCALL,CMD.EOT});
			   			Log.d("debug","offcall");
			   		}
			   		else{
			   			Log.d("debug","no offcall");
			   		}
					SG.connectedThread.write(new byte[]{CMD.SOT,CMD.SWCHMOD,STATE.CURRENT_MODE,CMD.EOT});
					SG.manager.semBTout.release();   
		 
		    break;
		   case TelephonyManager.CALL_STATE_RINGING:
			   STATE.CALL_NOTIFIED=true;
			try {
				SG.manager.semBTout.acquire();
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
				SG.connectedThread.write(new byte[]{CMD.SOT,CMD.SWCHMOD,MOD.LOG,CMD.EOT});
				SG.connectedThread.write(new byte[]{CMD.SOT,CMD.CALL});
				SG.connectedThread.write(incomingNumber.toString().getBytes());
				SG.connectedThread.write(new byte[]{CMD.SEP});
				SG.connectedThread.write((SG.manager.ContactFromNumber(incomingNumber)).getBytes());
				SG.connectedThread.write(new byte[]{CMD.EOT});
				SG.connectedThread.write(new byte[]{CMD.SOT,CMD.CALL});
				SG.manager.semBTout.release();
				
		  
		    break;
		   default:
		    break;
		   }
		  }

}
