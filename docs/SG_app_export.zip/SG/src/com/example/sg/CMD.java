package com.example.sg;

public class CMD {
	
	public static final byte SOT = 0x1;
	public static final byte EOT = 0x17;
	public static final byte SEP = 0x1D;
	public static final byte ACK = 0x6;
	public static final byte NAK = 0x15;
	
	public static final byte CALL = 0x11;
	public static final byte SMS = 0x12;
	
	public static final byte OFFCALL = 0x13;
	public static final byte OFFSMS = 0x14;
	
	public static final byte ALARM = 0x2B;
	public static final byte ERROR = 0x5;
	public static final byte GPS = 0x24;
	
	
	public static final byte DEBUG = 0x21;
	
	public static final byte SWCHMOD = 0x7;
	
	public static final byte TIME = 0x16;
	
	
	
	
}
