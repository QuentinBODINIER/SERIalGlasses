package com.example.sg;

import android.app.Activity;

public class DirectionActivity extends Activity {

}
