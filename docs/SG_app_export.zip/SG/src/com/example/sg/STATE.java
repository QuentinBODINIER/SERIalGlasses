package com.example.sg;

public class STATE {
	public static boolean SMS_NOTIFIED=false;
	public static boolean CALL_NOTIFIED=false;
	public static byte CURRENT_MODE=MOD.SPLASH;
}
