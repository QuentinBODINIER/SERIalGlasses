package com.example.sg;

public class MOD {
	public static final byte LOG = 0x30;
	public static final byte CLOCK = 0x31;
	public static final byte ACCEL = 0x32;
	public static final byte DEMO = 0x33;
	public static final byte SPLASH = 0x34;
}
